#ifndef LAB4_H
#define LAB4_H

int ChooseTwo(int n);
int Factorial(int n);

#endif
