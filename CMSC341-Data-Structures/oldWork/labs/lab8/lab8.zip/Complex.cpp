#include "Complex.h"

// Complex class constructor
Complex::Complex(double real, double imaginary) : 
  m_real(real), m_imaginary(imaginary)
{
  
}

// Accessor that returns real part of complex number
double Complex::GetReal() const
{
  return m_real;
}

// Accessor that returns imaginary part of complex number
double Complex::GetImaginary() const
{
  return m_imaginary;
}

// Start writing your code here ....
