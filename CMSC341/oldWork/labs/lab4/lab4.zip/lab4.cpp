#include <iostream>
#include "lab4.h"

using namespace std;

int main() {

  /* Compute and display Factorial(i) for i = 5..10 */

  for (int i = 5; i <= 10; ++i)
    cout << "Factorial(" << i << ") = " << Factorial(i) << endl;

  /* Compute and display ChooseTwo(i) for i = 5..10 */

  for (int i = 5; i <= 10; ++i)
    cout << "ChooseTwo(" << i << ") = " << ChooseTwo(i) << endl;
}

int ChooseTwo(int n) {
  if (n < 2)
    return -1;
  else
    return (n*(n-1))/2;
}

/* IMPLEMENT Factorial() HERE */

    
  
